import React from 'react'

const ForgottenPass = () => {
  return (
    <div>ForgottenPass</div>
  )
}

export default ForgottenPass